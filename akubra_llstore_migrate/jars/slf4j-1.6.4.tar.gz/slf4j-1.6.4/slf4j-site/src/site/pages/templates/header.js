
document.write('<table width="100%" border="0"><tr>');
document.write('<td><a href="http://www.slf4j.org/">');
document.write('<img src="' + prefix + 'images/logos/slf4j-logo.jpg" alt="" border="0"/>');
document.write('</a></td>')

//document.write('<td align="right"><a id="job" href="http://logback.qos.ch/job.html">');
//document.write('<img src="' + prefix + 'images/myjob.png" alt="" border="0"/>');
//document.write('</a></td>')

document.write('</tr></table>');
document.write('<div id="breadcrumbs"></div>');